#include <gtk/gtk.h>


void
on_cabuttonlogin_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttongdcretour_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_acbgdcrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void sendmail(char body[]);

void
on_cabuttonsretour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttongdc_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_cabuttons__curit___clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_cabuttonquitter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_acrbdebit_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_acrbdechet_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_acrbf_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_acrbm_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_acrbt_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_caradiobuttondebit_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_caradiobuttonmfumee_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_caradiobuttonmtemp_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_caradiobuttonmmouv_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_caentrymdone_changed                (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_caradiobuttonmdechet_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_cabuttonmretour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonmvalider_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_cabuttonldtadministrateur_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonldtnutritioninste_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonldtadr_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonldtadf_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonldtsrh_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_cabuttonldttechnicien_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_acrbretour_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_ouijesuissure_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_acsbs_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_acsbsretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);



void
on_ouijesuissure12_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_acrbrvald12_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_acdtree56_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_acctreeviews55_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeviewtrax_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_accbmvalider_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_caatreeviewgdc_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_cawindowmodifier_focus_in_event     (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

gboolean
on_acwindowsupprimer_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);
